package ui;

public class Application {
	
	
	public static void main(String[] args)
	{
		EchoCLI cli = new EchoCLI();
		
		cli.mainLoop();

	}
	
	
}
